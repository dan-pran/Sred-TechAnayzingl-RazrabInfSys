#pragma once
#include "Storage.h"
#include <optional>
#include <vector>

namespace mp {

    class CategoryRepository {
    public:
        explicit CategoryRepository(Storage& storage);

        int  create(const CategoryRecord& cat);
        std::optional<CategoryRecord> findByName(const std::string& name);

        void assignItem(int categoryId, int mediaId);
        std::vector<MediaRecord> getItems(int categoryId);

    private:
        Storage& storage_;
    };

} // namespace mp