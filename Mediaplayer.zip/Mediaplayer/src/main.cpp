#include "Storage.h"
#include "MediaRepository.h"
#include "PlaylistRepository.h"
#include "CategoryRepository.h"
#include "MediaLibrary.h"
#include "Player.h"
#include <windows.h>

#include <iostream>
#include <memory>

using namespace mp;

int main() {
    SetConsoleOutputCP(CP_UTF8);
    try {
    auto storage = createStorage("media_library.sqlite");
    storage.sync_schema();

    MediaRepository    mediaRepo(storage);
    PlaylistRepository playlistRepo(storage);
    CategoryRepository categoryRepo(storage);
    MediaLibrary       library(mediaRepo, playlistRepo, categoryRepo);

    int audioId = library.addMedia({
        0, "Bohemian Rhapsody", 354, "Rock", "Queen",
         "test.mp3", true
        });
    library.addMedia({
        0, "Inception Trailer", 150, "Sci-Fi", "Hans Zimmer",
        "https://example.com/trailers/inception.mp4", false
        });

    auto found = library.search(SearchQuery{ .title = "Bohemian" });
    for (const auto& m : found)
        std::cout << m.title << " (" << m.durationSec << "s)\n";

    int plId = library.createPlaylist("Favorites");
    std::cout << "plId = " << plId << ", audioId = " << audioId << std::endl;
    playlistRepo.addItem(plId, audioId);

    Player player;
    if (auto item = mediaRepo.findById(audioId)) {
        if (item->sourceUri.rfind("http", 0) == 0)
            player.setSource(std::make_unique<NetworkSource>());
        else
            player.setSource(std::make_unique<FileSource>());
        try {
            player.play(*item);
        }
        catch (const std::exception& e) {
            std::cerr << "Ошибка плеера: " << e.what() << std::endl;
        }
    }

    return 0;
    }
    catch (const std::system_error& e) {
        std::cerr << "SQLite error: " << e.what() << std::endl;
        std::cerr << "Error code: " << e.code().value() << std::endl;
        return 1;
    }
}