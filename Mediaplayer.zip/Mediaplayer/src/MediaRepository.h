#pragma once
#include "Storage.h"
#include <optional>
#include <vector>

namespace mp {

    class MediaRepository {
    public:
        explicit MediaRepository(Storage& storage);

        int save(const MediaRecord& item);
        void remove(int id);

        std::optional<MediaRecord> findById(int id);
        std::vector<MediaRecord> findAll();
        std::vector<MediaRecord> findByTitle(const std::string& substr);
        std::vector<MediaRecord> findByGenre(const std::string& genre);
        std::vector<MediaRecord> findByArtist(const std::string& artist);
        std::vector<MediaRecord> findByDurationRange(int minSec, int maxSec);
        std::vector<MediaRecord> findByGenreAndDuration(const std::string& genre,
            int minSec, int maxSec);

    private:
        Storage& storage_;
    };

} // namespace mp