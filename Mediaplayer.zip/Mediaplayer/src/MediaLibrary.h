#pragma once
#include "MediaRepository.h"
#include "PlaylistRepository.h"
#include "CategoryRepository.h"
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace mp {

    struct SearchQuery {
        std::optional<std::string> title;
        std::optional<std::string> genre;
        std::optional<std::string> artist;
        std::optional<int>         minDuration;
        std::optional<int>         maxDuration;
    };

    class MediaLibrary {
    public:
        MediaLibrary(MediaRepository& mediaRepo,
            PlaylistRepository& playlistRepo,
            CategoryRepository& categoryRepo);

        int addMedia(const MediaRecord& item);
        int createPlaylist(const std::string& name);

        std::vector<MediaRecord> search(const SearchQuery& q);

        std::map<std::string, std::vector<MediaRecord>> groupByGenre();
        std::map<std::string, std::vector<MediaRecord>> groupByArtist();

    private:
        MediaRepository& mediaRepo_;
        PlaylistRepository& playlistRepo_;
        CategoryRepository& categoryRepo_;
    };

} // namespace mp