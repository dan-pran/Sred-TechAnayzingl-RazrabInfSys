#include "CategoryRepository.h"

using namespace mp;
using namespace sqlite_orm;

CategoryRepository::CategoryRepository(Storage& storage) : storage_(storage) {}

int CategoryRepository::create(const CategoryRecord& cat) {
    return storage_.insert(cat);
}

std::optional<CategoryRecord> CategoryRepository::findByName(const std::string& name) {
    auto vec = storage_.get_all<CategoryRecord>(
        where(c(&CategoryRecord::name) == name));
    if (vec.empty()) return std::nullopt;
    return vec.front();
}

void CategoryRepository::assignItem(int categoryId, int mediaId) {
    storage_.insert(CategoryItemRecord{ categoryId, mediaId });
}

std::vector<MediaRecord> CategoryRepository::getItems(int categoryId) {
    std::vector<MediaRecord> result;
    auto links = storage_.get_all<CategoryItemRecord>(
        where(c(&CategoryItemRecord::categoryId) == categoryId));
    for (const auto& link : links) {
        auto items = storage_.get_all<MediaRecord>(
            where(c(&MediaRecord::id) == link.mediaId));
        if (!items.empty()) result.push_back(items.front());
    }
    return result;
}