#pragma once
#include "Domain.h"
#include <fstream>
#include <memory>
#include <stdexcept>
#include <string>

namespace mp {

    class MediaSource {
    public:
        virtual ~MediaSource() = default;
        virtual bool   open(const std::string& uri) = 0;
        virtual size_t read(char* buffer, size_t size) = 0;
        virtual void   close() = 0;
    };

    class FileSource : public MediaSource {
    public:
        bool   open(const std::string& uri) override;
        size_t read(char* buffer, size_t size) override;
        void   close() override;
    private:
        std::ifstream file_;
    };

    class NetworkSource : public MediaSource {
    public:
        bool   open(const std::string& uri) override;
        size_t read(char* buffer, size_t size) override;
        void   close() override;
    private:
        std::string uri_;
    };

    class Player {
    public:
        void setSource(std::unique_ptr<MediaSource> source);
        void play(const MediaRecord& item);
        void pause();
        void stop();

    private:
        std::unique_ptr<MediaSource> source_;
    };

} // namespace mp