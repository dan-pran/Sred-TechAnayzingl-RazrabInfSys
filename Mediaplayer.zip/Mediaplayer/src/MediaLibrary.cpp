#include "MediaLibrary.h"

using namespace mp;

MediaLibrary::MediaLibrary(MediaRepository& mediaRepo,
    PlaylistRepository& playlistRepo,
    CategoryRepository& categoryRepo)
    : mediaRepo_(mediaRepo),
    playlistRepo_(playlistRepo),
    categoryRepo_(categoryRepo) {
}

int MediaLibrary::addMedia(const MediaRecord& item) {
    return mediaRepo_.save(item);
}

int MediaLibrary::createPlaylist(const std::string& name) {
    return playlistRepo_.create(PlaylistRecord{ 0, name });
}

std::vector<MediaRecord> MediaLibrary::search(const SearchQuery& q) {
    std::vector<MediaRecord> result;
    for (const auto& m : mediaRepo_.findAll()) {
        if (q.title && m.title.find(*q.title) == std::string::npos) continue;
        if (q.genre && m.genre != *q.genre)                    continue;
        if (q.artist && m.artist != *q.artist)                   continue;
        if (q.minDuration && m.durationSec < *q.minDuration)         continue;
        if (q.maxDuration && m.durationSec > *q.maxDuration)         continue;
        result.push_back(m);
    }
    return result;
}

std::map<std::string, std::vector<MediaRecord>> MediaLibrary::groupByGenre() {
    std::map<std::string, std::vector<MediaRecord>> out;
    for (const auto& m : mediaRepo_.findAll())
        out[m.genre].push_back(m);
    return out;
}

std::map<std::string, std::vector<MediaRecord>> MediaLibrary::groupByArtist() {
    std::map<std::string, std::vector<MediaRecord>> out;
    for (const auto& m : mediaRepo_.findAll())
        out[m.artist].push_back(m);
    return out;
}