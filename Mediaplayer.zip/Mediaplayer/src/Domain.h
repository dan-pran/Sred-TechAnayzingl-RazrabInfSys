#pragma once
#include <string>

namespace mp {

    struct MediaRecord {
        int id = 0;
        std::string title;
        int durationSec = 0;
        std::string genre;
        std::string artist;
        std::string sourceUri;
        bool isAudio = true;
    };

    struct PlaylistRecord {
        int id = 0;
        std::string name;
    };

    struct CategoryRecord {
        int id = 0;
        std::string name;
        std::string type;  // "genre" | "artist" | "user"
    };

    struct PlaylistItemRecord {
        int playlistId = 0;
        int mediaId = 0;
    };

    struct CategoryItemRecord {
        int categoryId = 0;
        int mediaId = 0;
    };

} // namespace mp