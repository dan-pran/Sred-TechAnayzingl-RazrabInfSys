#pragma once
#include "Storage.h"
#include <optional>
#include <vector>

namespace mp {

    class PlaylistRepository {
    public:
        explicit PlaylistRepository(Storage& storage);

        int  create(const PlaylistRecord& pl);
        std::optional<PlaylistRecord> findById(int id);

        void addItem(int playlistId, int mediaId);
        void removeItem(int playlistId, int mediaId);
        std::vector<MediaRecord> getItems(int playlistId);

    private:
        Storage& storage_;
    };

} // namespace mp