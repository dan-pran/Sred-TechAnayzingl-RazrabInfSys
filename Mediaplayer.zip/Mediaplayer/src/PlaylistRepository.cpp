#include "PlaylistRepository.h"
#include <stdexcept>

using namespace mp;
using namespace sqlite_orm;

PlaylistRepository::PlaylistRepository(Storage& storage) : storage_(storage) {}

int PlaylistRepository::create(const PlaylistRecord& pl) {
    storage_.insert(pl);
    auto found = storage_.get_all<PlaylistRecord>(
        where(c(&PlaylistRecord::name) == pl.name),
        order_by(&PlaylistRecord::id).desc(),
        limit(1)
    );
    return found.empty() ? 0 : found.front().id;
}

std::optional<PlaylistRecord> PlaylistRepository::findById(int id) {
    auto vec = storage_.get_all<PlaylistRecord>(where(c(&PlaylistRecord::id) == id));
    if (vec.empty()) return std::nullopt;
    return vec.front();
}

void PlaylistRepository::addItem(int playlistId, int mediaId) {
    if (playlistId <= 0 || mediaId <= 0) {
        throw std::invalid_argument("playlistId and mediaId must be positive");
    }
    storage_.replace(PlaylistItemRecord{ playlistId, mediaId });
}

void PlaylistRepository::removeItem(int playlistId, int mediaId) {
    storage_.remove_all<PlaylistItemRecord>(
        where(c(&PlaylistItemRecord::playlistId) == playlistId
            and c(&PlaylistItemRecord::mediaId) == mediaId));
}

std::vector<MediaRecord> PlaylistRepository::getItems(int playlistId) {
    std::vector<MediaRecord> result;
    auto links = storage_.get_all<PlaylistItemRecord>(
        where(c(&PlaylistItemRecord::playlistId) == playlistId));
    for (const auto& link : links) {
        auto items = storage_.get_all<MediaRecord>(
            where(c(&MediaRecord::id) == link.mediaId));
        if (!items.empty()) result.push_back(items.front());
    }
    return result;
}