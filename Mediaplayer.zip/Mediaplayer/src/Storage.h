#pragma once
#include <string>
#include <sqlite_orm/sqlite_orm.h>
#include "Domain.h"

namespace mp {

    inline auto createStorage(const std::string& dbFile) {
        using namespace sqlite_orm;
        return make_storage(dbFile,
            make_table("media",
                make_column("id", &MediaRecord::id, primary_key().autoincrement()),
                make_column("title", &MediaRecord::title),
                make_column("duration_sec", &MediaRecord::durationSec),
                make_column("genre", &MediaRecord::genre),
                make_column("artist", &MediaRecord::artist),
                make_column("source_uri", &MediaRecord::sourceUri),
                make_column("is_audio", &MediaRecord::isAudio)
            ),
            make_table("playlists",
                make_column("id", &PlaylistRecord::id, primary_key().autoincrement()),
                make_column("name", &PlaylistRecord::name)
            ),
            make_table("playlist_items",
                make_column("playlist_id", &PlaylistItemRecord::playlistId),
                make_column("media_id", &PlaylistItemRecord::mediaId),
                primary_key(&PlaylistItemRecord::playlistId, &PlaylistItemRecord::mediaId)
            ),
            make_table("categories",
                make_column("id", &CategoryRecord::id, primary_key().autoincrement()),
                make_column("name", &CategoryRecord::name),
                make_column("type", &CategoryRecord::type)
            ),
            make_table("category_items",
                make_column("category_id", &CategoryItemRecord::categoryId),
                make_column("media_id", &CategoryItemRecord::mediaId),
                primary_key(&CategoryItemRecord::categoryId, &CategoryItemRecord::mediaId)
            )
        );
    }

    using Storage = decltype(createStorage(""));

} // namespace mp