#include "Player.h"

using namespace mp;

// ─── FileSource ───
bool FileSource::open(const std::string& uri) {
    std::string path = uri;
    // Отрезаем префикс file:///, если он есть
    const std::string prefix = "file:///";
    if (path.rfind(prefix, 0) == 0) {
        path = path.substr(prefix.length());
    }

    file_.open(path, std::ios::binary);
    return file_.is_open();
}
size_t FileSource::read(char* buffer, size_t size) {
    file_.read(buffer, static_cast<std::streamsize>(size));
    return static_cast<size_t>(file_.gcount());
}
void FileSource::close() {
    if (file_.is_open()) file_.close();
}

// ─── NetworkSource (заглушка) ───
bool NetworkSource::open(const std::string& uri) {
    uri_ = uri;
    return true;
}
size_t NetworkSource::read(char*, size_t) { return 0; }
void   NetworkSource::close() {}

// ─── Player ───
void Player::setSource(std::unique_ptr<MediaSource> source) {
    source_ = std::move(source);
}

void Player::play(const MediaRecord& item) {
    if (!source_ || !source_->open(item.sourceUri))
        throw std::runtime_error("Cannot open media source: " + item.sourceUri);
    // В реальном коде здесь — FFmpeg/libVLC/GStreamer
}

void Player::pause() { /* ... */ }

void Player::stop() {
    if (source_) source_->close();
}