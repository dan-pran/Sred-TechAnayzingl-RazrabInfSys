#include "MediaRepository.h"

using namespace mp;
using namespace sqlite_orm;

MediaRepository::MediaRepository(Storage& storage) : storage_(storage) {}

int MediaRepository::save(const MediaRecord& item) {
    storage_.insert(item);
    auto found = storage_.get_all<MediaRecord>(
        where(c(&MediaRecord::title) == item.title
            and c(&MediaRecord::artist) == item.artist),
        order_by(&MediaRecord::id).desc(),
        limit(1)
    );
    return found.empty() ? 0 : found.front().id;
}

void MediaRepository::remove(int id) {
    storage_.remove<MediaRecord>(id);
}

std::optional<MediaRecord> MediaRepository::findById(int id) {
    auto vec = storage_.get_all<MediaRecord>(where(c(&MediaRecord::id) == id));
    if (vec.empty()) return std::nullopt;
    return vec.front();
}

std::vector<MediaRecord> MediaRepository::findAll() {
    return storage_.get_all<MediaRecord>();
}

std::vector<MediaRecord> MediaRepository::findByTitle(const std::string& substr) {
    return storage_.get_all<MediaRecord>(
        where(like(&MediaRecord::title, "%" + substr + "%")));
}

std::vector<MediaRecord> MediaRepository::findByGenre(const std::string& genre) {
    return storage_.get_all<MediaRecord>(where(c(&MediaRecord::genre) == genre));
}

std::vector<MediaRecord> MediaRepository::findByArtist(const std::string& artist) {
    return storage_.get_all<MediaRecord>(where(c(&MediaRecord::artist) == artist));
}

std::vector<MediaRecord> MediaRepository::findByDurationRange(int minSec, int maxSec) {
    return storage_.get_all<MediaRecord>(
        where(between(&MediaRecord::durationSec, minSec, maxSec)));
}

std::vector<MediaRecord> MediaRepository::findByGenreAndDuration(
    const std::string& genre, int minSec, int maxSec) {
    return storage_.get_all<MediaRecord>(
        where(c(&MediaRecord::genre) == genre
            and between(&MediaRecord::durationSec, minSec, maxSec)));
}